
export function sayHelloWorld(world: string) {
  return `Hello ${world}`;
}
